To the extent possible under law, Mapbox has waived all copyright and related or neighboring rights to Mapbox Navigation SDK Examples. This work is published from the United States.

CC0 1.0 Universal (CC0 1.0)
Public Domain Dedication
https://creativecommons.org/publicdomain/zero/1.0/