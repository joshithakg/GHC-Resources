package com.mapbox.examples.androidauto.car.search

class GetPlacesError internal constructor(
    val errorMessage: String,
    val throwable: Throwable?
)
